/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : main.c
 * Version      : 0.9
 ******************************************************************************/
#include <stdio.h>
#include "types.h"

#include "rdk_cmn_gic.h"
#include "rdk_uart_16750.h"
#include "emmc_hal.h"
#include "emmc_std.h"
#include "emmc_def.h"
#include "emmc_config.h"
#include "emmc_registers.h"

/*-----------------------------------------------------------*/

#define BOOT_IMAGE_PARTITION PARTITION_ID_BOOT_0

#define BASEADDR_RAMB0 0xB6000000

#define BOOT_PARAM_BLOCK_SIZE 1
#define BOOT_PARAM_LOAD_SIZE_OFFSEET 0
#define BOOT_PARAM_CHECKSUM_OFFSEET 4
#define BOOT_PARAM_ALIGNMENT sizeof(uint32_t)

#define EMM_BLOCK_SIZ 512

#define SECOND_LOADER_PARM 0x100
#define SECOND_LOADER_BLOCK 0x101
#define SECOND_LOADER_MAX_SIZ 1024 * 1024 // 1Mbyte

#define SECOND_LOAD_MAIN_ADDR 0xB6000100
int (*SecondLoaderMain)(void);

struct st_boot_param {
	uint32_t size;
	uint32_t checksum;
	void *addr_load;
};

struct st_load_param {
	struct st_boot_param second_loader;
	struct st_boot_param u_boot;
	uint32_t *blok_buf;
};

extern void InitPFC(void);
extern void PowerOnRAMB(void);
extern void UartSetup(void);

static void get_bootparam(uint32_t *buf, struct st_boot_param *param);
static BOOL sum_check(struct st_boot_param param);
static void error_routine(void);

int main(void)
{
	struct st_load_param boot_param;
	uint32_t boot_pram_buf[EMM_BLOCK_SIZ * BOOT_PARAM_BLOCK_SIZE /
			       sizeof(uint32_t)];
	uint32_t read_block_size;

	boot_param.blok_buf = boot_pram_buf;
    boot_param.second_loader.addr_load = (void*)BASEADDR_RAMB0;

	/* initialize GIC driver */
	Init_GIC(0);
    
	/* Set Pin Function */
	InitPFC();
    
	/* Initialize CPG */
	InitCPG();
    
	/* Initialize RAMB */
	PowerOnRAMB();

	/* Initialize UART */
	UartSetup();
    
    /* Boot log */
    uart0_print("[BL1] Boot Loader Version 1.00\n");

	/*Initialize eMMC*/
	if (EMMC_SUCCESS != emmc_init(FALSE)) { /* Normal clock mode */
		uart0_print("[BL1] [Error] emmc_init()\n");
		goto error_finished;
	};
	if (EMMC_SUCCESS != emmc_memcard_power(TRUE)) {
		uart0_print("[BL1] [Error] emmc_memcard_power()\n");
		goto error_finished;
	};
	if (EMMC_SUCCESS != emmc_mount()) {
		uart0_print("[BL1] [Error] emmc_mount error()\n");
		goto error_finished;
	};
	if (EMMC_SUCCESS != emmc_select_partition(BOOT_IMAGE_PARTITION)) {
		uart0_print("[BL1] [Error] emmc_select_partition()\n");
		goto error_finished;
	};

	uart0_print("[BL1] eMMC initialized\n");

	/* Load boot parameter for 2nd loader */
	if (EMMC_SUCCESS != emmc_read_sector(boot_param.blok_buf,
					     SECOND_LOADER_PARM,
					     BOOT_PARAM_BLOCK_SIZE,
					     LOADIMAGE_FLAGS_DMA_ENABLE)) {
		uart0_print("[BL1]  [Error] emmc_read_sector() for 2nd boot loader parameter\n");
		goto error_finished;
	}

	uart0_print("[BL1] Loaded the boot parameter for 2nd boot\n");

	get_bootparam(boot_param.blok_buf, &boot_param.second_loader);
	if (SECOND_LOADER_MAX_SIZ < boot_param.second_loader.size) {
		uart0_print("[BL1] [Error] Over size the 2nd boot loader\n");
		goto error_finished;
	}

	read_block_size = boot_param.second_loader.size / EMM_BLOCK_SIZ;
	if (0 < boot_param.second_loader.size % EMM_BLOCK_SIZ) {
		read_block_size += 1;
	}

	/* Load the 2nd loader */
	if (EMMC_SUCCESS !=
	    emmc_read_sector((uint32_t *)boot_param.second_loader.addr_load,
			     SECOND_LOADER_BLOCK, read_block_size, 0)) {
		uart0_print("[BL1]  [Error] emmc_read_sector() for 2nd boot loader\n");
		goto error_finished;
	}

	/* Checksum for 2nd loader */
	if (TRUE != sum_check(boot_param.second_loader)) {
		uart0_print("[BL1]  [Error] sum_check() for 2nd boot loader\n");
		goto error_finished;
	}

	uart0_print("[BL1] Loaded the 2nd boot loader\n");

	/* Kick the 2nd Loader*/
	uart0_print("[BL1] Kick the 2nd boot loader\n");
    SecondLoaderMain = (void*)SECOND_LOAD_MAIN_ADDR;
	SecondLoaderMain();

    while(1){;} //not reach here.
	return 0;

error_finished:
    return -1;
}

void get_bootparam(uint32_t *buf, struct st_boot_param *param)
{

	int i_size;
	int i_cheksum;

	i_size = BOOT_PARAM_LOAD_SIZE_OFFSEET / BOOT_PARAM_ALIGNMENT;
	param->size = buf[i_size];

	i_cheksum = BOOT_PARAM_CHECKSUM_OFFSEET / BOOT_PARAM_ALIGNMENT;
	param->checksum = buf[i_cheksum];
}

BOOL sum_check(struct st_boot_param param)
{

	uint16_t *p_current;
	uint16_t sum = 0;
	uint16_t *end;

	p_current = (uint16_t *)param.addr_load;
	end = (int)param.addr_load + param.size - (param.size % 2);

	while (end > p_current) {
		sum += *p_current++;
	}

	if (1 == param.size % 2) {
		sum += *p_current & 0x00FF;
	}

	if (sum == param.checksum) {
		return TRUE;
	}

	return FALSE;
}

void error_routine(void) {
    uart0_print("[BL1] [Error] 1st loader is failed"); 
}
