/*******************************************************************************
 * RENESAS CONFIDENTIAL
 * This source code is subject to non-disclosure agreement.
 ******************************************************************************/
/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : rdk_ddr_api.h
 * Description  : API information for MMC/DDI
 ******************************************************************************/

#ifndef RDK_DDR_API_H
#define RDK_DDR_API_H

/** typedef defines */
typedef enum
{
    DDR_ERROR_TIMEOUT               = -501,
    DDR_ERROR_TRAINING_FAILED       = -502,
} e_ddr_error_code_t;


#define DDR_MEM_START_ADDR                 (0x0100000000ULL)
#define DDR_MEM_END_ADDR                   (0x0200000000ULL)
#define DDR_MEM_START_MIRROR_ADDR          (0x0000000000ULL)
#define DDR_MEM_END_MIRROR_ADDR            (0x0080000000ULL)


/** Prototype definitions */
void MMC_InitialSetting(void);
void MMC_DisableRefAndPD(void);
void MMC_DisableSignal_dfi_init_complete(void);
void MMC_StartDfiInit(void);
void MMC_EnableSignal_dfi_init_complete(void);
void MMC_SetBackRegisters(void);
int32_t MMC_WaitBitForSW_Done(void);
int32_t MMC_WaitBitForDFI_INIT_COMPLETE(void);
int32_t MMC_WaitToDFI_NormalOperation(void);
void MMC_EnablePort(void);
int32_t DDI_InitalizePHY(void);
void DDI_DFI_InitComplete(void);


#endif  /* !defined(RDK_DDR_API_H) */
