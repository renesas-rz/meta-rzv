/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : rdk_cmn_icb.c
 * Description  : operation functions for ICB
 ******************************************************************************/

#include <stdint.h>
#include <stdbool.h>

#include "rdk_common.h"
#include "rdk_cmn_icb.h"

static const T_ICB_DDR_INFO gs_icb_ddr =
{
    .device_conf = 0x00000000,
    .device_size = 0x00000002,   // for RZ/V2M Evaluation Kit
    .timing[0]   = 0x1B1B111A,
    .timing[1]   = 0x10040806,
    .timing[2]   = 0x00000602
};


uint32_t ICB_ReadReg(uint32_t offset)
{
    return (CMN_REG_Read32(ICB_BASE_ADDRESS + offset));
}

void ICB_WriteReg(uint32_t offset, uint32_t value)
{
    CMN_REG_Write32((ICB_BASE_ADDRESS + offset), value);
}

int32_t ICB_SetDDRSche(void)
{
    ICB_WriteReg(ICB_SCHE_DEVICESIZE, gs_icb_ddr.device_size);
    return CMN_SUCCESS;
}


/*- End of file -*/
