/*******************************************************************************
 * RENESAS CONFIDENTIAL
 * This source code is subject to non-disclosure agreement.
 ******************************************************************************/
/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : rdk_ddr_api.c
 * Description  : operation functions for DDR
 ******************************************************************************/

#include <stdbool.h>
#include <stdint.h>

#include "rdk_common.h"
#include "rdk_cmn_cpg.h"
#include "rdk_ddr_reg.h"
#include "rdk_ddr_api.h"

typedef struct
{
    uint32_t addr;
    uint16_t data;
} st_ddi_setting_data_t;

typedef struct
{
    uint32_t addr;
    uint32_t data;
} st_mmc_setting_data_t;

typedef struct
{
    uint32_t id;
    uint32_t rsv1;
    uint32_t size;
    uint32_t rsv2;
    uint16_t data[32360];
} st_ddi_imem_data_t;

typedef struct
{
    uint32_t id;
    uint32_t rsv1;
    uint32_t size;
    uint32_t rsv2;
    uint16_t data[1672];
} st_ddi_dmem_data_t;

#define DEBUG_CHECKSUM                  0

#define DDR_NO_DATA_SYMBOL              (0xFFFFFFFF)

#define DDI_IMEM_SIZE                   (0x4000)
#define DDI_DMEM_SIZE                   (0x2000)

#define DDI_TRANING_FW_WAIT_IN_US       (10)
#define DDI_TRANING_FW_TIMEOUT          (500000)

#define MMC_STAT_WAIT_IN_US             (10)
#define MMC_STAT_TIMEOUT                (500000)

#define STATIC  static


#include "b_lpddr4_cfg_ddi_PinSwizzle.h"                // for RZ/V2M Evaluation Kit
#include "b_lpddr4_cfg_ddi_Retention.h"
#include "b_lpddr4_tfw.h"
#include "b_lpddr4_cfg_ddi_Rank2_MemoryLPDDR4-3200.h"   // for RZ/V2M Evaluation Kit
#include "b_lpddr4_cfg_mmc_real_16_2_LPDDR4-3200.h"     // for RZ/V2M Evaluation Kit


uint32_t MMC_ReadReg(uint32_t offset)
{
	return (CMN_REG_Read32(MMC_BASE_ADDRESS + offset));
}

void MMC_WriteReg(uint32_t offset, uint32_t value)
{
	CMN_REG_Write32((MMC_BASE_ADDRESS + offset), value);
}

uint16_t DDI_ReadReg(uint32_t offset)
{
	return (CMN_REG_Read32(DDI_BASE_ADDRESS + offset)) & 0x0FFFF;
}

void DDI_WriteReg(uint32_t offset, uint16_t value)
{
	CMN_REG_Write32((DDI_BASE_ADDRESS + offset), value);
}

STATIC void mmc_SetData(const st_mmc_setting_data_t *p_data)
{
    uint32_t i;

    for ( i=0; DDR_NO_DATA_SYMBOL != p_data[i].addr; i++ )
    {
        MMC_WriteReg(p_data[i].addr, p_data[i].data);
    }
}


void MMC_InitialSetting(void)
{
	mmc_SetData(gs_ddr_mmc_Step_2);
}

void MMC_DisableRefAndPD(void)
{
    MMC_WriteReg(MMC_RFSHCTL3,
        (MMC_ReadReg(MMC_RFSHCTL3) & (~MMC_RFSHCTL3_DIS_AUTO_REFRESH))
        | MMC_RFSHCTL3_DIS_AUTO_REFRESH);

    MMC_WriteReg(MMC_PWRCTL,
        (MMC_ReadReg(MMC_PWRCTL) &
            (~(MMC_PWRCTL_SELFREF_EN |
               MMC_PWRCTL_POWERDOWN_EN))));
}

void MMC_DisableSignal_dfi_init_complete(void)
{
    MMC_WriteReg(MMC_SWCTL, 0);
    MMC_WriteReg(MMC_DFIMISC,
        (MMC_ReadReg(MMC_DFIMISC) & (~MMC_DFIMISC_DFI_INIT_COMPLETE_EN)) );
    MMC_WriteReg(MMC_SWCTL, MMC_SWCTL_SW_DONE);
}

void MMC_StartDfiInit(void)
{
    MMC_WriteReg(MMC_SWCTL, 0);
    MMC_WriteReg(MMC_DFIMISC,
        (MMC_ReadReg(MMC_DFIMISC) & (~MMC_DFIMISC_DFI_INIT_START))
        | MMC_DFIMISC_DFI_INIT_START );
    MMC_WriteReg(MMC_SWCTL, MMC_SWCTL_SW_DONE);

}

void MMC_EnableSignal_dfi_init_complete(void)
{
    MMC_WriteReg(MMC_SWCTL, 0);
    MMC_WriteReg(MMC_DFIMISC,
        (MMC_ReadReg(MMC_DFIMISC) &
            (~(MMC_DFIMISC_DFI_INIT_START))));

    MMC_WriteReg(MMC_DFIMISC,
        (MMC_ReadReg(MMC_DFIMISC) &
            (~(MMC_DFIMISC_DFI_INIT_COMPLETE_EN)))
        | MMC_DFIMISC_DFI_INIT_COMPLETE_EN );

    MMC_WriteReg(MMC_PWRCTL,
        (MMC_ReadReg(MMC_PWRCTL) & (~MMC_PWRCTL_SELFREF_SW)));
    MMC_WriteReg(MMC_SWCTL, MMC_SWCTL_SW_DONE);
}


void MMC_SetBackRegisters(void)
{
    MMC_WriteReg(0x0060, ((MMC_ReadReg(0x0060) & 0xFFFFFFFE) | 0x00000000));
    MMC_WriteReg(0x0030, ((MMC_ReadReg(0x0030) & 0xFFFFFFDC) | 0x00000000));
}

int32_t MMC_WaitBitForSW_Done(void)
{
    int32_t rslt = CMN_SUCCESS;
    uint32_t cnt = MMC_STAT_TIMEOUT;
    uint32_t swstat;

    while (true)
    {
        swstat = MMC_ReadReg(MMC_SWSTAT);
        if (0 != (swstat & MMC_SWSTAT_SW_DONW_ACK))
        {
            break;
        }
        if (0 == cnt)
        {
            rslt = DDR_ERROR_TIMEOUT;
            break;
        }
        else
        {
            CMN_DelayInUS(MMC_STAT_WAIT_IN_US);
            cnt--;
        }
    }

    return rslt;
}


int32_t MMC_WaitBitForDFI_INIT_COMPLETE(void)
{
    int32_t rslt = CMN_SUCCESS;
    uint32_t cnt = MMC_STAT_TIMEOUT;
    uint32_t dfistat;

    while (true)
    {
        dfistat = MMC_ReadReg(MMC_DFISTAT);
        if (0 != (dfistat & MMC_DFISTAT_DFI_INIT_COMPLETE))
        {
            break;
        }

        if (0 == cnt)
        {
            rslt = DDR_ERROR_TIMEOUT;
            break;
        }
        else
        {
            CMN_DelayInUS(MMC_STAT_WAIT_IN_US);
            cnt--;
        }
    }

    return rslt;
}


int32_t MMC_WaitToDFI_NormalOperation(void)
{
    int32_t rslt = CMN_SUCCESS;
    uint32_t cnt = MMC_STAT_TIMEOUT;
    uint32_t stat;

    while (true)
    {
        stat = MMC_ReadReg(MMC_STAT);

        if (1 == (stat & MMC_STAT_OPERATING_MODE_MASK))
        {
            break;
        }

        if (0 == cnt)
        {
            rslt = DDR_ERROR_TIMEOUT;
            break;
        }
        else
        {
            CMN_DelayInUS(MMC_STAT_WAIT_IN_US);
            cnt--;
        }
    }

    return rslt;
}


void MMC_EnablePort(void)
{
    MMC_WriteReg(MMC_MP_PCTRL0, MMC_PCTRL_N_PORT_EN);
}


STATIC void ddi_SetPhyData(const st_ddi_setting_data_t *p_data)
{
    uint32_t i;

    for ( i=0; DDR_NO_DATA_SYMBOL != p_data[i].addr; i++ )
    {
        DDI_WriteReg(p_data[i].addr, p_data[i].data);
    }
}


STATIC void ddi_Load_IMEMImage(const st_ddi_imem_data_t *p_data)
{
    uint32_t i;
    uint32_t offset;

    DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0000);

    for (i = 0, offset=0x00050000 * 4 ;
         i < (p_data->size/sizeof(uint16_t));
         i++, offset+=4 )
    {
        DDI_WriteReg(offset, p_data->data[i]);
    }

    while (offset < (0x00054000 * 4))
    {
        DDI_WriteReg(offset, 0x0000U);
        offset += 4;
    }

    DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0001);
}


STATIC void ddi_Load_DMEMImage(const st_ddi_dmem_data_t *p_data)
{
    uint32_t i;
    uint32_t offset;

    DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0000);

    for (i = 0, offset = 0x00054000 * 4;
         i < (p_data->size/sizeof(uint16_t));
         i++, offset += 4)
    {
        DDI_WriteReg(offset, p_data->data[i]);
    }

    DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0001);
}


STATIC int32_t ddi_ExecuteTrainingFW(void)
{
    int32_t rslt = CMN_SUCCESS;
    uint16_t reg_data;
    uint32_t cnt;

    do
    {
        DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICRORESET, 0x0009);
        DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICRORESET, 0x0001);
        DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICRORESET, 0x0000);

        cnt = DDI_TRANING_FW_TIMEOUT;
        while (true)
        {
            reg_data = DDI_ReadReg(DDI_DWC_DDRPHYA_APBONLY0_UCTSHADOWREGS);
            if (0 == (reg_data & 0x0001))
            {
                break;
            }
            if (0 == cnt)
            {
                rslt = DDR_ERROR_TIMEOUT;
                break;
            }
            else
            {
                CMN_DelayInUS(DDI_TRANING_FW_WAIT_IN_US);
                cnt--;
            }
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        reg_data = DDI_ReadReg(DDI_DWC_DDRPHYA_APBONLY0_UCTWRITEONLYSHADOW);
        if (0x07 != (reg_data & 0xFF))
        {
            rslt = DDR_ERROR_TRAINING_FAILED;
            break;
        }

        DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_DCTWRITEPROT, 0x0000);

        cnt = DDI_TRANING_FW_TIMEOUT;
        while (true)
        {
            reg_data = DDI_ReadReg(DDI_DWC_DDRPHYA_APBONLY0_UCTSHADOWREGS);
            if (1 == (reg_data & 0x0001))
            {
                break;
            }
            if (0 == cnt)
            {
                rslt = DDR_ERROR_TIMEOUT;
                break;
            }
            else
            {
                CMN_DelayInUS(DDI_TRANING_FW_WAIT_IN_US);
                cnt--;
            }
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_DCTWRITEPROT, 0x0001);

        DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICRORESET, 0x0001);

    } while (0);

    return rslt;
}


STATIC void ddi_SavePhyRetentionData(void)
{
    uint32_t i;

    for ( i=0; DDR_NO_DATA_SYMBOL != gs_ddr_ddi_Retention[i].addr; i++ )
    {
        gs_ddr_ddi_Retention[i].data =
            DDI_ReadReg(gs_ddr_ddi_Retention[i].addr);
    }
}


STATIC void ddi_RestorePhyRetentionData(void)
{
    uint32_t i;

    for ( i=0; DDR_NO_DATA_SYMBOL != gs_ddr_ddi_Retention[i].addr; i++ )
    {
        DDI_WriteReg(gs_ddr_ddi_Retention[i].addr,
                     gs_ddr_ddi_Retention[i].data);
    }
}


int32_t DDI_InitalizePHY(void)
{
    int32_t res;

    do
    {
        ddi_SetPhyData(gs_ddr_ddi_InitCfg);

        ddi_SetPhyData(gs_ddr_ddi_PinSwizzle);

        DDI_WriteReg(DDI_DWC_DDRPHYA_MASTER0_MEMRESETL, 0x0002);

        ddi_Load_IMEMImage(&gs_ddr_ddi_1IMEM);

        if (true )
        {
            CPG_SetDifClkFreq(CPG_DDIV_MMCDDI, 0x0001, 0x0000);

            ddi_Load_DMEMImage(&gs_ddr_ddi_1DMEM_PS0);

            res = ddi_ExecuteTrainingFW();
            if (CMN_SUCCESS != res)
            {
                break;
            }

            DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0000);
            DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0001);

        }

        if (true )
        {
            CPG_SetDifClkFreq(CPG_DDIV_MMCDDI, 0x0001, 0x0000);

            ddi_Load_IMEMImage(&gs_ddr_ddi_2IMEM);
            ddi_Load_DMEMImage(&gs_ddr_ddi_2DMEM);
            res = ddi_ExecuteTrainingFW();
            if (CMN_SUCCESS != res)
            {
                break;
            }
            DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0000);
            DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0001);
        }

        ddi_SetPhyData(gs_ddr_ddi_InitEngine);

        res = CMN_SUCCESS;
    } while (0);

    return (res);
}


void DDI_DFI_InitComplete(void)
{
    uint16_t reg_data;

    DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0000);
    DDI_WriteReg(DDI_DWC_DDRPHYA_DRTUB0_UCCLKHCLKENABLES, 0x0003);

    reg_data = DDI_ReadReg(DDI_DWC_DDRPHYA_MASTER0_CALRATE);
    reg_data = (reg_data & 0xFF0F) | 0x0010;
    DDI_WriteReg(DDI_DWC_DDRPHYA_MASTER0_CALRATE, reg_data);

    DDI_WriteReg(DDI_DWC_DDRPHYA_DRTUB0_UCCLKHCLKENABLES, 0x0000);
    DDI_WriteReg(DDI_DWC_DDRPHYA_APBONLY0_MICROCONTMUXSEL, 0x0001);
}




/*- End of File -*/
