/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : main.c
 * Version      : 0.9
 ******************************************************************************/

#include "types.h"
/* Standard includes. */
#include <stdio.h>

#include "rdk_uart_16750.h"
#include "emmc_hal.h"
#include "emmc_std.h"
#include "emmc_def.h"
#include "emmc_config.h"
#include "emmc_registers.h"

#define BOOT_IMAGE_PARTITION PARTITION_ID_BOOT_0

#define BOOT_PARAM_BLOCK_SIZE 1
#define BOOT_PARAM_LOAD_SIZE_OFFSEET 0
#define BOOT_PARAM_CHECKSUM_OFFSEET 4
#define BOOT_PARAM_ALIGNMENT sizeof(uint32_t)

#define EMM_BLOCK_SIZ	512
#define U_BOOT_PARM	0x901
#define U_BOOT_BLOCK 0x902
#define U_BOOT_MAX_SIZ 2*1024*1024 //2Mbyte

#define U_BOOT_ADDR 0x57F00000
void (*u_boot)(void);


extern void HardwareSetup(void);
extern void UartSetup(void);

struct st_boot_param{
	uint32_t size;
	uint32_t checksum;
	void* addr_load;
};

struct st_load_param{
	struct st_boot_param second_loader;
	struct st_boot_param u_boot;
	uint32_t* blok_buf;
};

static void get_bootparam(uint32_t *buf,struct st_boot_param *param);
static BOOL sum_check(struct st_boot_param param);
static void error_routine(void);

__attribute__((section(".entry")))
int main( void )
{
	struct st_load_param boot_param;
	uint32_t boot_pram_buf[EMM_BLOCK_SIZ*BOOT_PARAM_BLOCK_SIZE/sizeof(uint32_t)];
	uint32_t read_block_size;

	boot_param.blok_buf = boot_pram_buf;

	uart0_print("[BL2] 2nd boot loader entered\n");

	/*Init eMMC*/
	if(EMMC_SUCCESS != emmc_init(FALSE))
	{
		uart0_print("[BL2] [Error] emmc_init()\n");
		error_routine();
		return -1;
	};

	if(EMMC_SUCCESS != emmc_memcard_power(TRUE)){
		uart0_print("[BL2] [Error] emmc_memcard_power()\n");
		error_routine();
		return -1;
	};

	if(EMMC_SUCCESS != emmc_mount()){
		uart0_print("[BL2] [Error] emmc_mount()\n");
		error_routine();
		return -1;
	};

	if(EMMC_SUCCESS != emmc_select_partition(BOOT_IMAGE_PARTITION)){
		uart0_print("[BL2] [Error] emmc_select_partition()\n");
		error_routine();
		return -1;
	};

	/*- DDR setting -*/
	HardwareSetup(); 

	/*return from 2nd Loader*/
	/*Load U-Boot to DDR*/
    boot_param.u_boot.addr_load = (void*)U_BOOT_ADDR;

	if(EMMC_SUCCESS != emmc_read_sector(boot_param.blok_buf, U_BOOT_PARM, BOOT_PARAM_BLOCK_SIZE, LOADIMAGE_FLAGS_DMA_ENABLE)){
		uart0_print("[BL2] [Error] emmc_read_sector() for U-Boot parameter\n");
		error_routine();
		return -1;
	}

	uart0_print("[BL2] Loaded the boot parameter for U-Boot\n");

	get_bootparam(boot_param.blok_buf,&boot_param.u_boot);
	if(U_BOOT_MAX_SIZ < boot_param.u_boot.size){
		uart0_print("[BL2] [Error] Over size the U-Boot\n");
		error_routine();
		return -1;
	}

	read_block_size = boot_param.u_boot.size / EMM_BLOCK_SIZ;
	if(0 < (boot_param.u_boot.size % EMM_BLOCK_SIZ)){
		read_block_size += 1;
	}

	if(EMMC_SUCCESS != emmc_read_sector((uint32_t*)boot_param.u_boot.addr_load, U_BOOT_BLOCK, read_block_size, LOADIMAGE_FLAGS_DMA_ENABLE)){
		uart0_print("[BL2] [Error] emmc_read_sector() for U-Boot\n");
		error_routine();
		return -1;
	}

	if(TRUE != sum_check(boot_param.u_boot)){
		uart0_print("[BL2] [Error] sum_check() for U-Boot\n");
		error_routine();
		return -1;
	}

	uart0_print("[BL2] Loaded the U-Boot\n");

	/*Call U-Boot*/
	uart0_print("[BL2] theU-Boot start\n");
    u_boot = (void*)U_BOOT_ADDR;
	u_boot();
    
    while(1){;} //not reach here.
	return 0;
}

void get_bootparam(uint32_t *buf, struct st_boot_param *param )
{
	int i_size;
	int i_cheksum;

	i_size = BOOT_PARAM_LOAD_SIZE_OFFSEET / BOOT_PARAM_ALIGNMENT;
	param->size = buf[i_size];

	i_cheksum = BOOT_PARAM_CHECKSUM_OFFSEET / BOOT_PARAM_ALIGNMENT;
	param->checksum = buf[i_cheksum];
}

BOOL sum_check(struct st_boot_param param)
{

	uint16_t *p_current;
	uint16_t sum = 0;
	uint16_t *end;

	p_current = (uint16_t *)param.addr_load;
	end = (int)param.addr_load + param.size - (param.size % 2);

	while(end > p_current){
		sum += *p_current++;
	}

	if(1 == (param.size % 2) ){
		sum += *p_current & 0x00FF;
	}

	if(sum != param.checksum){
		return FALSE;
	}

	return TRUE;
}


static void error_routine(void)
{
	uart0_print("[BL2] 2nd boot loader is failed");	
}

/*- End of File -*/
