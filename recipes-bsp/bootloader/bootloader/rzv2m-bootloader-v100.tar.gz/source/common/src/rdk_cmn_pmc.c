/*******************************************************************************
 * RENESAS CONFIDENTIAL
 * This source code is subject to non-disclosure agreement.
 ******************************************************************************/
/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : rdk_cmn_pmc.c
 * Description  : operation functions for PMC
 ******************************************************************************/

#include <stdint.h>
#include <stdbool.h>

#include "rdk_common.h"
#include "rdk_cmn_pmc.h"
#include "rdk_cmn_cpg.h"
#ifdef LOADER2ND
#include "rdk_ddr_api.h"
#include "rdk_cmn_icb.h"
#endif

#include "rdk_uart_16750.h"

#define PMC_TIMEOUT_UNIT_IN_US (10)
#define PMC_SEQUENCE_POWER_ON_TIMEOUT (500000)
#define PMC_ISOLATION_OFF_TIMEOUT (500000)
#define PMC_CONNECTED_BUS_TIMEOUT (500000)
#define PMC_SEPARATED_BUS_TIMEOUT (500000)
#define PMC_ISOLATION_ON_TIMEOUT (500000)
#define PMC_SEQUENCE_POWER_OFF_TIMEOUT (500000)
#define PMC_RELEASE_RESET_TIMEOUT (500000)

#define PMC_WAIT_EVENT(m_toc, m_err_code, m_condition, m_rslt)                 \
	{                                                                      \
		uint32_t count = (m_toc) / PMC_TIMEOUT_UNIT_IN_US;             \
		while (true) {                                                 \
			if ((m_condition)) {                                   \
				(m_rslt) = CMN_SUCCESS;                        \
				break;                                         \
			}                                                      \
			if ((0 == (m_toc)) || (0 < count)) {                   \
				CMN_DelayInUS(PMC_TIMEOUT_UNIT_IN_US);         \
				count--;                                       \
			} else {                                               \
				(m_rslt) = (m_err_code);                       \
				break;                                         \
			}                                                      \
		}                                                              \
	}

typedef struct
{
	uint8_t reg_num;
	uint16_t target;
	uint16_t value;
} st_cpg_setting_data_t;

typedef struct
{
	uint32_t mem_time;
	uint16_t pwron_time;
} st_pmc_local_t;

static st_pmc_local_t gs_pmc_priv =
{
    .mem_time = 0x176F176F, /* PD_MEM External Power On/Off Wait: 2ms/2ms */
    .pwron_time = 0x176F,   /* PD External Power On Wait: 2ms */
};

uint32_t PMC_ReadReg(uint32_t offset)
{
	return (CMN_REG_Read32(PMC_BASE_ADDRESS + offset));
}

void PMC_WriteReg(uint32_t offset, uint32_t value)
{
	CMN_REG_Write32((PMC_BASE_ADDRESS + offset), value);
}

#ifdef LOADER2ND
typedef enum
{
    PMC_PD_AWO      = 0,
    PMC_PD_MEM      = 1,
    PMC_PD_CA53     = 7,
} e_pmc_kind_pd_t;

typedef enum
{
    PMC_ISOLATION_ON    = 0,
    PMC_ISOLATION_OFF   = 1,
    PMC_POWER_ON        = 0,
    PMC_POWER_OFF       = 1,
    PMC_BUS_CONNECT     = 0,
    PMC_BUS_SEPARATE    = 1
} e_pmc_on_off_t;

static int32_t pmc_TurnPower(e_pmc_kind_pd_t kind_pd, e_pmc_on_off_t on_flag)
{
    int32_t rslt = CMN_ERROR;
    uint32_t value;
    int32_t err_code;
    uint32_t timeout_c = 0;

    do
    {
        rslt = CMN_SUCCESS;
        switch (kind_pd)
        {
            case PMC_PD_MEM:
                value = PMC_SPLY_ENA_PD_MEM;
                break;
                
            default:
                rslt = PMC_ERROR_NO_EXIST_SPLY;
                break;
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        if (PMC_POWER_ON == on_flag)
        {
            value |= PMC_SPLY_ENA_PD_ON;
            timeout_c = PMC_SEQUENCE_POWER_ON_TIMEOUT;
            err_code = PMC_ERROR_POWER_ON_TIMEOUT;
        }
        else
        {
            timeout_c = PMC_SEQUENCE_POWER_OFF_TIMEOUT;
            err_code = PMC_ERROR_POWER_OFF_TIMEOUT;
        }
        PMC_WriteReg(PMC_SPLY_ENA, value);

        PMC_WAIT_EVENT(timeout_c, err_code,
            (0 != (PMC_ReadReg(PMC_INT_STS) & PMC_INT_STS_PD_DONE)),
            rslt);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        PMC_WriteReg(PMC_INT_CLR, PMC_INT_CLR_PD_DONE);
    }
    while (0);

    return rslt;
}

static int32_t pmc_TurnIsolation(e_pmc_kind_pd_t kind_pd, e_pmc_on_off_t on_flag)
{
    int32_t rslt = CMN_ERROR;
    uint32_t offset_reg_isoen = 0xFFFFFFFF;
    uint32_t value;
    int32_t err_code;
    uint32_t timeout_c = 0;

    do
    {
        rslt = CMN_SUCCESS;
        switch (kind_pd)
        {
            case PMC_PD_MEM:
                offset_reg_isoen = PMC_PD_MEM_ISOEN;
                break;
                
            default:
                rslt = PMC_ERROR_NO_EXIST_ISOLATION;
                break;
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        if (PMC_ISOLATION_ON == on_flag)
        {
            /* Turn On Isolation */
            value = PMC_PD_ISO_EN;
            timeout_c = PMC_ISOLATION_ON_TIMEOUT;
            err_code = PMC_ERROR_ISOLATION_ON_TIMEOUT;
        }
        else
        {
            /* Turn Off Isolation */
            value = 0;
            timeout_c = PMC_ISOLATION_OFF_TIMEOUT;
            err_code = PMC_ERROR_ISOLATION_OFF_TIMEOUT;
        }
        PMC_WriteReg(offset_reg_isoen, value);

        /* wait turn isolation */
        PMC_WAIT_EVENT(timeout_c, err_code,
            (0 != (PMC_ReadReg(offset_reg_isoen) & PMC_PD_ISO_DONE)), rslt);
    }
    while (0);

    return rslt;
}


static int32_t pmc_ConnectBus(e_pmc_kind_pd_t kind_pd, e_pmc_on_off_t on_flag)
{
    int32_t rslt = CMN_ERROR;
    uint32_t value;
    uint32_t offset_reg;
    uint32_t check_mask;
    uint32_t check_data = 0;
    uint32_t idle_check_mask;
    int32_t err_code;
    uint32_t timeout_c = 0;

    do
    {
        rslt = CMN_SUCCESS;
        switch (kind_pd)
        {
            case PMC_PD_MEM:
                value = PMC_IDLE_REQ_WEN_PD_MEM | 0x00000100UL;
                check_mask = PMC_IDLE_STS_PD_MEM_IDLE_DONE;
                break;

            default:
                rslt = PMC_ERROR_NO_EXIST_BUS_CONNECT;
                break;
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        idle_check_mask = check_mask;
        if (PMC_BUS_CONNECT == on_flag)
        {
            offset_reg = PMC_IDLE_STS;
            check_data = 0;
            timeout_c = PMC_CONNECTED_BUS_TIMEOUT;
            err_code = PMC_ERROR_CONNECTED_BUS_TIMEOUT;
        }else
        {
            value |= (value >> 16);
            offset_reg = PMC_INT_STS;
            check_mask = PMC_INT_STS_IDLE_DONE;
            check_data = check_mask;
            timeout_c = PMC_SEPARATED_BUS_TIMEOUT;
            err_code = PMC_ERROR_SEPARATED_BUS_TIMEOUT;
        }
        PMC_WriteReg(PMC_IDLE_REQ, value);

        PMC_WAIT_EVENT(timeout_c, err_code,
                (check_data == (PMC_ReadReg(offset_reg) & check_mask)),
                rslt);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        if (PMC_BUS_CONNECT != on_flag)
        {
            PMC_WriteReg(PMC_INT_CLR, check_data);
            if (0 == (PMC_ReadReg(PMC_IDLE_STS) & idle_check_mask))
            {
                rslt = PMC_ERROR_NOT_IDLE_BUS;
            }
        }
    }
    while(0);

    return rslt;
}

int32_t PMC_PowerOn_PD_MEM_FromPOR(void)
{
    int32_t rslt;

    do
    {
        CPG_SetClockCtrl(27, 0x0017, 0x0000);
        CPG_SetClockCtrl(16, 0x0020, 0x0000);
        CPG_SetClockCtrl(17, 0x0100, 0x0000);

        CPG_SetResetCtrl(7, 0x0002, 0x0000);

        CPG_SetPDResetCtrl(CPG_PD_RST_MEM_RSTB, CPG_PD_RST_MEM_RSTB);

        rslt = CPG_WakeUpPLL(CPG_PLL_3);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        PMC_WriteReg(PMC_PD_MEM_TIM, gs_pmc_priv.mem_time);

        rslt = pmc_TurnPower(PMC_PD_MEM, PMC_POWER_ON);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        CPG_SetClockCtrl(27, 0x0011, 0x0011);
        CMN_DelayInMS(210);

        rslt = pmc_TurnIsolation(PMC_PD_MEM, PMC_ISOLATION_OFF);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        CPG_SetClockCtrl(27, 0x0006, 0x0006);

        CPG_SetResetCtrl(15, 0x0008, 0x0008);

		CMN_DelayInMS(210);
        CPG_SetResetCtrl(15, 0x0010, 0x0010);

        MMC_InitialSetting();

        MMC_DisableRefAndPD();

        MMC_DisableSignal_dfi_init_complete();

        rslt = MMC_WaitBitForSW_Done();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        CPG_SetResetCtrl(15, 0x0005, 0x0005);

        CPG_SetResetCtrl(15, 0x0020, 0x0020);
        CMN_DelayInUS(1);

        CPG_SetResetCtrl(15, 0x0040, 0x0040);

        rslt = DDI_InitalizePHY();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        MMC_StartDfiInit();
        rslt = MMC_WaitBitForSW_Done();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }
        rslt = MMC_WaitBitForDFI_INIT_COMPLETE();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        MMC_EnableSignal_dfi_init_complete();
        rslt = MMC_WaitBitForSW_Done();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        rslt = MMC_WaitToDFI_NormalOperation();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        MMC_SetBackRegisters();

        DDI_DFI_InitComplete();

        MMC_EnablePort();

        CPG_SetResetCtrl(7, 0x0002, 0x0002);

        CMN_DelayInUS(5);

        CPG_SetClockCtrl(16, 0x0020, 0x0020);

        CPG_SetClockCtrl(17, 0x0100, 0x0100);

        rslt = pmc_ConnectBus(PMC_PD_MEM, PMC_BUS_CONNECT);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        rslt = ICB_SetDDRSche();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        cmn_SYS_WriteReg(0x020C, 0x01);

        uart0_print("[BL2] DDR initialization completed\n");

        rslt = CMN_SUCCESS;
    }
    while (0);

    return rslt;
}
#endif

/*- End of file -*/
