/*******************************************************************************
 * RENESAS CONFIDENTIAL
 * This source code is subject to non-disclosure agreement.
 ******************************************************************************/
/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name    : rdk_cmn_pmc.c
 * Description  : operation functions for PMC
 ******************************************************************************/

#include <stdint.h>
#include <stdbool.h>

#include "rdk_common.h"
#include "rdk_cmn_pmc.h"
#include "rdk_cmn_cpg.h"
#ifdef LOADER2ND
#include "rdk_ddr_api.h"
#include "rdk_cmn_icb.h"
#endif

#include "rdk_uart_16750.h"

#define PMC_TIMEOUT_UNIT_IN_US (10)
#define PMC_SEQUENCE_POWER_ON_TIMEOUT (500000)
#define PMC_ISOLATION_OFF_TIMEOUT (500000)
#define PMC_CONNECTED_BUS_TIMEOUT (500000)
#define PMC_SEPARATED_BUS_TIMEOUT (500000)
#define PMC_ISOLATION_ON_TIMEOUT (500000)
#define PMC_SEQUENCE_POWER_OFF_TIMEOUT (500000)
#define PMC_RELEASE_RESET_TIMEOUT (500000)

#define PMC_WAIT_EVENT(m_toc, m_err_code, m_condition, m_rslt)                 \
	{                                                                      \
		uint32_t count = (m_toc) / PMC_TIMEOUT_UNIT_IN_US;             \
		while (true) {                                                 \
			if ((m_condition)) {                                   \
				(m_rslt) = CMN_SUCCESS;                        \
				break;                                         \
			}                                                      \
			if ((0 == (m_toc)) || (0 < count)) {                   \
				CMN_DelayInUS(PMC_TIMEOUT_UNIT_IN_US);         \
				count--;                                       \
			} else {                                               \
				(m_rslt) = (m_err_code);                       \
				break;                                         \
			}                                                      \
		}                                                              \
	}

typedef struct
{
	uint8_t reg_num;
	uint16_t target;
	uint16_t value;
} st_cpg_setting_data_t;

typedef struct
{
	uint32_t mem_time;
	uint16_t pwron_time;
} st_pmc_local_t;

static st_pmc_local_t gs_pmc_priv =
{
    .mem_time = 0x176F176F, /* PD_MEM External Power On/Off Wait: 2ms/2ms */
    .pwron_time = 0x176F,   /* PD External Power On Wait: 2ms */
};

uint32_t PMC_ReadReg(uint32_t offset)
{
	return (CMN_REG_Read32(PMC_BASE_ADDRESS + offset));
}

void PMC_WriteReg(uint32_t offset, uint32_t value)
{
	CMN_REG_Write32((PMC_BASE_ADDRESS + offset), value);
}

#ifdef LOADER2ND
typedef enum
{
    PMC_PD_AWO      = 0,
    PMC_PD_MEM      = 1,
    PMC_PD_CA53     = 7,
} e_pmc_kind_pd_t;

typedef enum
{
    PMC_ISOLATION_ON    = 0,
    PMC_ISOLATION_OFF   = 1,
    PMC_POWER_ON        = 0,
    PMC_POWER_OFF       = 1,
    PMC_BUS_CONNECT     = 0,
    PMC_BUS_SEPARATE    = 1
} e_pmc_on_off_t;

static int32_t pmc_TurnPower(e_pmc_kind_pd_t kind_pd, e_pmc_on_off_t on_flag)
{
    int32_t rslt = CMN_ERROR;
    uint32_t value;
    int32_t err_code;
    uint32_t timeout_c = 0;

    do
    {
        rslt = CMN_SUCCESS;
        switch (kind_pd)
        {
            case PMC_PD_MEM:
                value = PMC_SPLY_ENA_PD_MEM;
                break;
                
            default:
                rslt = PMC_ERROR_NO_EXIST_SPLY;
                break;
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        if (PMC_POWER_ON == on_flag)
        {
            value |= PMC_SPLY_ENA_PD_ON;
            timeout_c = PMC_SEQUENCE_POWER_ON_TIMEOUT;
            err_code = PMC_ERROR_POWER_ON_TIMEOUT;
        }
        else
        {
            timeout_c = PMC_SEQUENCE_POWER_OFF_TIMEOUT;
            err_code = PMC_ERROR_POWER_OFF_TIMEOUT;
        }
        PMC_WriteReg(PMC_SPLY_ENA, value);

        PMC_WAIT_EVENT(timeout_c, err_code,
            (0 != (PMC_ReadReg(PMC_INT_STS) & PMC_INT_STS_PD_DONE)),
            rslt);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        PMC_WriteReg(PMC_INT_CLR, PMC_INT_CLR_PD_DONE);
    }
    while (0);

    return rslt;
}

static int32_t pmc_TurnIsolation(e_pmc_kind_pd_t kind_pd, e_pmc_on_off_t on_flag)
{
    int32_t rslt = CMN_ERROR;
    uint32_t offset_reg_isoen = 0xFFFFFFFF;
    uint32_t value;
    int32_t err_code;
    uint32_t timeout_c = 0;

    do
    {
        rslt = CMN_SUCCESS;
        switch (kind_pd)
        {
            case PMC_PD_MEM:
                offset_reg_isoen = PMC_PD_MEM_ISOEN;
                break;
                
            default:
                rslt = PMC_ERROR_NO_EXIST_ISOLATION;
                break;
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        if (PMC_ISOLATION_ON == on_flag)
        {
            /* Turn On Isolation */
            value = PMC_PD_ISO_EN;
            timeout_c = PMC_ISOLATION_ON_TIMEOUT;
            err_code = PMC_ERROR_ISOLATION_ON_TIMEOUT;
        }
        else
        {
            /* Turn Off Isolation */
            value = 0;
            timeout_c = PMC_ISOLATION_OFF_TIMEOUT;
            err_code = PMC_ERROR_ISOLATION_OFF_TIMEOUT;
        }
        PMC_WriteReg(offset_reg_isoen, value);

        /* wait turn isolation */
        PMC_WAIT_EVENT(timeout_c, err_code,
            (0 != (PMC_ReadReg(offset_reg_isoen) & PMC_PD_ISO_DONE)), rslt);
    }
    while (0);

    return rslt;
}


static int32_t pmc_ConnectBus(e_pmc_kind_pd_t kind_pd, e_pmc_on_off_t on_flag)
{
    int32_t rslt = CMN_ERROR;
    uint32_t value;
    uint32_t offset_reg;
    uint32_t check_mask;
    uint32_t check_data = 0;
    uint32_t idle_check_mask;
    int32_t err_code;
    uint32_t timeout_c = 0;

    do
    {
        rslt = CMN_SUCCESS;
        switch (kind_pd)
        {
            case PMC_PD_MEM:
                value = PMC_IDLE_REQ_WEN_PD_MEM | 0x00000100UL;
                check_mask = PMC_IDLE_STS_PD_MEM_IDLE_DONE;
                break;

            default:
                rslt = PMC_ERROR_NO_EXIST_BUS_CONNECT;
                break;
        }
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        idle_check_mask = check_mask;
        if (PMC_BUS_CONNECT == on_flag)
        {
            offset_reg = PMC_IDLE_STS;
            check_data = 0;
            timeout_c = PMC_CONNECTED_BUS_TIMEOUT;
            err_code = PMC_ERROR_CONNECTED_BUS_TIMEOUT;
        }else
        {
            value |= (value >> 16);
            offset_reg = PMC_INT_STS;
            check_mask = PMC_INT_STS_IDLE_DONE;
            check_data = check_mask;
            timeout_c = PMC_SEPARATED_BUS_TIMEOUT;
            err_code = PMC_ERROR_SEPARATED_BUS_TIMEOUT;
        }
        PMC_WriteReg(PMC_IDLE_REQ, value);

        PMC_WAIT_EVENT(timeout_c, err_code,
                (check_data == (PMC_ReadReg(offset_reg) & check_mask)),
                rslt);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        if (PMC_BUS_CONNECT != on_flag)
        {
            PMC_WriteReg(PMC_INT_CLR, check_data);
            if (0 == (PMC_ReadReg(PMC_IDLE_STS) & idle_check_mask))
            {
                rslt = PMC_ERROR_NOT_IDLE_BUS;
            }
        }
    }
    while(0);

    return rslt;
}

int32_t PMC_PowerOn_PD_MEM_FromPOR(void)
{
    int32_t rslt;

    do
    {
        /** A) release RESET for PD_MEM */
        /** A-1 Clock off */
        uart0_print("[BL2] A-1:Clock off for PD_MEM\n");
        CPG_SetClockCtrl(27, 0x0017, 0x0000);
        CPG_SetClockCtrl(16, 0x0020, 0x0000);
        CPG_SetClockCtrl(17, 0x0100, 0x0000);

        /** A-2 Reset */
        uart0_print("[BL2] A-2:Reset for PD_MEM\n");
        CPG_SetResetCtrl(7, 0x0002, 0x0000);

        CPG_SetPDResetCtrl(CPG_PD_RST_MEM_RSTB, CPG_PD_RST_MEM_RSTB);

        /** B) PLL3 wake up */
        /** B-1) check mode is standby for PLL3 */
        /** B-2) Set param PLL3_CLK1 */
        /** B-3) Set param PLL3_CLK2 */
        /** B-4) release standby mode for PLL3 */
        /** B-5) check PLL Lock for PLL3 */
        uart0_print("[BL2] B-1:Check mode is standby for PLL3\n");
        uart0_print("[BL2] B-2:Set param PLL3_CLK1\n");
        uart0_print("[BL2] B-3:Set param PLL3_CLK2\n");
        uart0_print("[BL2] B-4:Release standby mode for PLL3\n");
        uart0_print("[BL2] B-5:Check PLL Lock for PLL3\n");
        rslt = CPG_WakeUpPLL(CPG_PLL_3);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        /** C) Power on for PD_MEM */
        /** C-1) Setting PD_MEM power on/off time for external */
        /**       power source */
        uart0_print("[BL2] C-1:Setting PD_MEM power on/off time for external power source\n");
        PMC_WriteReg(PMC_PD_MEM_TIM, gs_pmc_priv.mem_time);

        /** C-2) start sequence power on for PD_MEM */
        /** C-3) wait finished sequence */
        /** C-4) clear interrput status */
        uart0_print("[BL2] C-2:Start sequence power on for PD_MEM\n");
        uart0_print("[BL2] C-3:Wait finished sequence\n");
        uart0_print("[BL2] C-4:Clear interrput status\n");
        rslt = pmc_TurnPower(PMC_PD_MEM, PMC_POWER_ON);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        /** C-5) start supplies clock and 1us wait */
        /**  refer to uPCTL2_Initialization_190425.xlsx
         **  step 1:
         **   1-1) Assert reset signals : all... default setting...
         **   1-2) Wait 8 DfiClocks (CLK_ON27:CLK0)
         **   1-3) De-assert presetn and PwrOkln (RST15:Unit3,4)
         **   1-4) Wait 130 core clock or aclk (CLK_ON27:CLK0,4)
         **/
        /** CPG_CLK_ON27 : CLK0, 4 */
        uart0_print("[BL2] C-5:Start supplies clock and 1us wait\n");
        CPG_SetClockCtrl(27, 0x0011, 0x0011);
        CMN_DelayInUS(1);
		CMN_DelayInMS(200);
        /** C-6) isolation off for PD_MEM */
        /** C-7) check isolation off */
        uart0_print("[BL2] C-6:Isolation off for PD_MEM\n");
        uart0_print("[BL2] C-7:Check isolation off\n");
        rslt = pmc_TurnIsolation(PMC_PD_MEM, PMC_ISOLATION_OFF);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        /** D-1) start supplies clock */
        /** CPG_CLK_ON27 : CLK1, 2 */
        uart0_print("[BL2] D-1:Start supplies clock(CLK_ON27)\n");
        CPG_SetClockCtrl(27, 0x0006, 0x0006);

        /** D) release RESET and start supplies clock */
        /** D-2) release RESET for MMC APB Register */
        /** CPG_RST15 : UNIT3 : PRESETN(Type-A) */
        uart0_print("[BL2] D-2:Release RESET for MMC APB Register\n");
        CPG_SetResetCtrl(15, 0x0008, 0x0008);

        /** D-3) MMC_CORE_DDRC_CORE_CLK and MMC_ACLK 130 clocks wait */
        /**      (800-200 MHz) and (400-100MHz) 130 clocks */
        /**      10ns* 130 = 1300ns for minimux 100MHz */
        /**      instead of 2us wait */
        uart0_print("[BL2] D-3:MMC_CORE_DDRC_CORE_CLK and MMC_ACLK 130 clocks wait\n");
        CMN_DelayInUS(2);
		CMN_DelayInMS(200);
        /** D-4) release Cold Reset for DDI */
        /** CPG_RST15 : UNIT4 PWROK(Type-A) */
        uart0_print("[BL2] D-4:Release Cold Reset for DDI\n");
        CPG_SetResetCtrl(15, 0x0010, 0x0010);

        /** E) Initialize MMC */
        /** E-1) Setting parameter to MMC Register for LPDDR4 SDRAM */
        /**  refer to uPCTL2_Initialization_190425.xlsx
         **   step 2 : Initialize MMC set values
         **/
        uart0_print("[BL2] E-1:Setting parameter to MMC Register for LPDDR4 SDRAM\n");
        MMC_InitialSetting();

        /** E-2) disable function to auto-refresh, self-refresh
         **      and powerdown
         **/
        uart0_print("[BL2] E-2:Disable function to auto-refresh, self-refresh and powerdown\n");
        MMC_DisableRefAndPD();

        /** E-3) set disable to use signal of dfi_init_complete to MMC
         **/
        uart0_print("[BL2] E-3:Set disable to use signal of dfi_init_complete to MMC\n");
        MMC_DisableSignal_dfi_init_complete();

        /** E-4) check write prohibited from register */
        uart0_print("[BL2] E-4:Check write prohibited\n");
        rslt = MMC_WaitBitForSW_Done();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        /** E-5) release RESET data path for MMC */
        /**  refer to uPCTL2_Initialization_190425.xlsx
         **   step 3 : De-assert core reset
         **            core_ddrc_rstn = 1b, aresetn=1b
         **   step 4-7 = E-2-E-4
         **/
        /** CPG_RST15 : UNIT2, 0 */
        uart0_print("[BL2] E-5:Release RESET data path for MMC\n");
        CPG_SetResetCtrl(15, 0x0005, 0x0005);

        /** F) Initialize DDI */
        /**  refer to uPCTL2_Initialization_190425.xlsx
         **  step 8:
         **  8-1) De-assert Reset : RESET=0b.
         **  8-2) Wait 2 APBCLKs
         **       DDI_APBCLK=100/50/48 MHz...
         **       48MHz x 2 clocks = 42ns.. < 1us..
         **  8-3) De-assert RESETn_APB=1b.
         **/
        /** F-1) release RESET for DDI */
        /** CPG_RST15 : UNIT5 : DDI:RESET(Type-A) */
        uart0_print("[BL2] F-1:Release RESET for DDI\n");
        CPG_SetResetCtrl(15, 0x0020, 0x0020);
        CMN_DelayInUS(1);

        /** F-2) release RESET for DDI APB */
        /** CPG_RST15 : UNIT6 : DDI:RESET_APB(Type-A) */
        uart0_print("[BL2] F-2:Release RESET for DDI APB\n");
        CPG_SetResetCtrl(15, 0x0040, 0x0040);

        /** F-3) set param to configuration register for LPDDR4 */
        /** F-4) Load firmware image to PHY */
        /** F-5) start training, and get result if finished training. */
        /** F-6) Load firmwaer image for PHY init Engine */
        /** F-7) move to mission mode for PHY */
        /** F-8) release dfi_init_complete signal */
        /** MMC Register SWCTL[0].sw_done = 0 */
        /** MMC Register DFIMISC[0].dfi_init_complete_en = 1 */
        /** MMC Register SWCTL[0].sw_done = 1 */
        /**  refer to uPCTL2_Initialization_190425.xlsx
         **  step 9-14 : Execute PHY initialize setting
         **     equal F-3 - F-7 (maybe...)
         **/
        uart0_print("[BL2] F-3:Set param to configuration register for LPDDR4\n");
        uart0_print("[BL2] F-4:Load firmware image to PHY\n");
        uart0_print("[BL2] F-5:Start training, and get result if finished training\n");
        uart0_print("[BL2] F-6:Load firmwaer image for PHY init Engine\n");
        uart0_print("[BL2] F-7:Move to mission mode for PHY\n");
        uart0_print("[BL2] F-8:Release dfi_init_complete signal\n");
        rslt = DDI_InitalizePHY();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        /**  refer to uPCTL2_Initialization_190425.xlsx
         **  step 15-18 : DFI initialize
         **/
        uart0_print("[BL2] F-9:DFI initialize\n");
        MMC_StartDfiInit();
        rslt = MMC_WaitBitForSW_Done();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }
        rslt = MMC_WaitBitForDFI_INIT_COMPLETE();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        /**  step 19-24 : DFI operational mode
         **/
        uart0_print("[BL2] F-10:DFI operational mode\n");
        MMC_EnableSignal_dfi_init_complete();
        rslt = MMC_WaitBitForSW_Done();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }
        rslt = MMC_WaitToDFI_NormalOperation();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        /**  step 25    : Set back registers in step 4 to
         **               the original values if desired
         **/
        MMC_SetBackRegisters();

        /**  step 26-31 : Save traning results.
         **/
        DDI_DFI_InitComplete();

        /** G) Enable Bus */
        /** G-1) Enable MMC AXI Bus Access */
        /**  MMC Register PCTRL_0(+0x0490).port_en[0] = 1 */
        /**  This setting is existed in MMC Initialize setting... */
        uart0_print("[BL2] G-1:Enable MMC AXI Bus Access\n");
        MMC_EnablePort();

        /** G-2) release RESET for PD_MEM ICB */
        /** CPG_RST7  : UNIT1 */
        uart0_print("[BL2] G-2:Release RESET for PD_MEM ICB\n");
        CPG_SetResetCtrl(7, 0x0002, 0x0002);

        /** G-3) 50nsec wait */
        uart0_print("[BL2] G-3:50nsec wait\n");
        CMN_DelayInUS(1);

        /** G-4) start supplies clock for PD_MEM ICB */
        /** CPG_CLK_ON16 : CLK5 */
        uart0_print("[BL2] G-4:Start supplies clock for PD_MEM ICB\n");
        CPG_SetClockCtrl(16, 0x0020, 0x0020);

        /** CPG_CLK_ON17 : CLK8 */
        CPG_SetClockCtrl(17, 0x0100, 0x0100);

        /** G-5) set connected bus */
        /** G-6) check connected bus */
        uart0_print("[BL2] G-5:Set connected bus\n");
        uart0_print("[BL2] G-6:Check connected bus\n");
        rslt = pmc_ConnectBus(PMC_PD_MEM, PMC_BUS_CONNECT);
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        /** Appendix set value to ICB register */
        uart0_print("[BL2] G-7:Appendix set value to ICB register\n");
        rslt = ICB_SetDDRSche();
        if (CMN_SUCCESS != rslt)
        {
            break;
        }

        cmn_SYS_WriteReg(0x020C, 0x01);

        rslt = CMN_SUCCESS;
    }
    while (0);

    return rslt;
}
#endif

/*- End of file -*/
