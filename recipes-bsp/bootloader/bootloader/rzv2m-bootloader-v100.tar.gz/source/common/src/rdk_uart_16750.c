/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/ 
/*******************************************************************************
 * File Name	: rdk_uart_16750.c
 ******************************************************************************/

#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "rdk_common.h"
#include "rdk_uart_16750.h"

#define UART_CH0_BASE (0xA4040000UL)

#define UART_STAT_NONE (0U)
#define UART_STAT_RX_READY (0x00000001U)
#define UART_STAT_TX_READY (0x00000002U)
#define UART_STAT_ERROR (0x80000000U)

#define UART_LSR_ERROR_MASK													   \
	(UART_16550_LINE_STATUS_FE | UART_16550_LINE_STATUS_PE |			   \
	 UART_16550_LINE_STATUS_OE)
#define UART_LSR_RXRDY_MASK (UART_16550_LINE_STATUS_DR)
#define UART_LSR_TXRDY_MASK													   \
	(UART_16550_LINE_STATUS_TEMT | UART_16550_LINE_STATUS_THRE)
#define UART_LSR_READY_MASK (UART_LSR_TXRDY_MASK | UART_LSR_RXRDY_MASK)

static int32_t uart_16550_fifo_size_get_tx(size_t *size);
static int32_t uart_16550_line_status_get(uint32_t *status);

/******************************************************************************
 *	Global variables
 ******************************************************************************/

static st_UART_REG_t *gs_uART_cReg = (st_UART_REG_t *)UART_CH0_BASE; /** UART Control Regster Top Pointer */

static int uart_init(st_UART_REG_t *p_reg, unsigned long ulBaudRate)
{

	volatile unsigned long i;
	unsigned long bit_rate;

	// UART Target Channel set
	gs_uART_cReg = p_reg;

	// UART initialize reset.
	gs_uART_cReg->FCR = UART_MODE_CONST_FCR_RST;	// Reset Rx,Rx FIFO
	gs_uART_cReg->HCR0 |= 0x0080;					// S/W Reset
	for (i = 0; i < 1000; i++)
		;											// Delay Over 6*PLCK(For fail soft)
	gs_uART_cReg->HCR0 &= ~(0x0080);				// S/W Reset release
	for (i = 0; i < 1000; i++)
		;											// Delay Over 6*PLCK(For fail soft)

	// UART set bit rate.
	gs_uART_cReg->LCR |= 0x0080;					// Select Div. Latch Register
	bit_rate = SCLK / (ulBaudRate * 16);
	gs_uART_cReg->DLL = (uint8_t)bit_rate;
	gs_uART_cReg->DLM = (uint8_t)(bit_rate >> 8);

	gs_uART_cReg->LCR = UART_MODE_CONST_LCR;		// Select Data Buff & Set Parity,etc.

	gs_uART_cReg->IER = UART_MODE_CONST_IER_P;		// Set Int. All Disable
	gs_uART_cReg->FCR = UART_MODE_CONST_FCR_P;		// Set Int. FIFO Trigger Level,etc.
	gs_uART_cReg->MCR = UART_MODE_CONST_MCR_P;		// Set Flow Ctl. Enable/Disble,etc.
	
	// Reset Tx&Rx DMA_REQ
	gs_uART_cReg->HCR0 = 0x0000;
    
	return (0);
}

int uart0_init(unsigned long ulBaudRate)
{
	return uart_init((st_UART_REG_t *)UART_CH0_BASE, ulBaudRate);
}

static int strlenwk(const char *str)
{
	int length = 0;
	while (*str++ != '\0') {
		length++;
	}
	return length;
}

int uart0_print(const char *in_str)
{
	int status;
	int i, j;
	int len = strlenwk(in_str);
	size_t size_tx;
	uint32_t line_status = 0;

	status = uart_16550_fifo_size_get_tx(&size_tx);

	for (i = 0; i < 1000; ++i) {
		if (status != CMN_SUCCESS) {
			break;
		}

		if (len == 0) {
			break;
		}

		/** Wait for the THRE line status */
		j = 1000000;
		while (--j) {
			line_status = 0;
			status = uart_16550_line_status_get(&line_status);
			if (status != CMN_SUCCESS) {
				break;
			}
			if (line_status & (UART_16550_LINE_STATUS_THRE |
					   UART_16550_LINE_STATUS_TEMT)) {
				break;
			}
		}
		if (j == 0) {
			status = CMN_ERROR;
		}

		gs_uART_cReg->RBR_THR = *in_str;
		len--;
		in_str++;
	}

	return status;
}

/*-------------------------------------------------------------------------------*/
/* Local Functions	*/
/*-------------------------------------------------------------------------------*/

static int32_t uart_16550_fifo_size_get_tx(size_t *p_size)
{
	if (0 != p_size) {
		*p_size = 16;
	}
	return (CMN_SUCCESS);
}

static int32_t uart_16550_line_status_get(uint32_t *p_status)
{

	if (0 != p_status) {
		*p_status = gs_uART_cReg->LSR;
	}
	return (CMN_SUCCESS);
}
